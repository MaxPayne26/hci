<?php
// Include database configuration
include 'config/config.php';

// Check if email parameter is set in the URL
if (isset($_GET['email'])) {
    // Retrieve email from URL parameter
    $email = $_GET['email'];

    // Update verification status in the database
    $sql = "UPDATE users SET VerificationStatus = 'Verified' WHERE Email = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("s", $email);

    if ($stmt->execute()) {
        // Close statement
        $stmt->close();
        // Close connection
        $con->close();
        // Display success alert using JavaScript and redirect to index.php
        echo '<script>alert("Email verification successful. You can now login."); window.location.href = "index.php";</script>';
    } else {
        // Close statement
        $stmt->close();
        // Close connection
        $con->close();
        // Display error alert using JavaScript
        echo '<script>alert("Error updating verification status. Please try again later.");</script>';
    }
} else {
    // Display error alert using JavaScript if email parameter is not provided
    echo '<script>alert("Email parameter not provided.");</script>';
}
?>
