<!DOCTYPE html>
<!-- Created By CodingNepal -->
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>Popup Register Form Design</title>
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
   </head>
   <body>
      <div class="center">
         <input type="checkbox" id="show">
         <label for="show" class="show-btn">View Form</label>
         <div class="container">
            <label for="show" class="close-btn fas fa-times" title="close"></label>
            <div class="text">
               Login Form
            </div>
            <form action="register_proc.php" method="post">
               <div class="data">
                  <label>Username</label>
                  <input type="text" name="username" id="username" required>
               </div>
               <div class="data">
                <label>Email</label>
                <input type="email" name="email" id="email" required>
             </div>
             <div class="data">
                <label>Age</label>
                <input type="number" name="age" id="age" required>
             </div>
               <div class="data">
                  <label>Password</label>
                  <input type="password" name="password" id="password" required>
               </div>
               <div class="btn">
                  <div class="inner"></div>
                  <button type="submit">Register</button>
               </div>
               <div class="signup-link">
                  Already a member? <a href="index.php">Log in now</a>
               </div>
            </form>
         </div>
      </div>
   </body>
</html>