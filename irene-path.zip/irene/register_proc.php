<?php
// Include database configuration
include 'config/config.php';

// Check if the connection was successful
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Include Composer's autoloader
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = $_POST["username"];
    $email = $_POST["email"];
    $age = $_POST["age"];
    $password = $_POST["password"];
    
    // Perform basic validation
    if (empty($username) || empty($email) || empty($age) || empty($password)) {
        // Handle empty fields
        echo "Please fill in all fields.";
    } else {
        // Validate email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo "Invalid email format.";
        } else {
            // Check password length
            if (strlen($password) < 6) {
                echo "Password must be at least 6 characters long.";
            } else {
                // Generate 4-digit verification code
                $verification_code = rand(1000, 9999);
                
                // Set default value for VerificationStatus
                $verification_status = 'Not Verified';
                
                // Prepare SQL statement to insert user data into the database
                $sql = "INSERT INTO users (Username, Email, Age, Password, VerificationCode, VerificationStatus) VALUES (?, ?, ?, ?, ?, ?)";
                
                // Prepare and bind parameters
                $stmt = $con->prepare($sql);
                $stmt->bind_param("sssiss", $username, $email, $age, $password, $verification_code, $verification_status);
                
                // Execute the statement
                if ($stmt->execute()) {
                    // Registration successful, send verification email
                    try {
                        // Create PHPMailer object
                        $mail = new PHPMailer(true);
                        
                        // Server settings
                        $mail->isSMTP();
                        $mail->Host = 'smtp.gmail.com';
                        $mail->SMTPAuth = true;
                        $mail->Username = 'mr.red092697@gmail.com';
                        $mail->Password = 'ezoavahtxokotkbp';
                        $mail->SMTPSecure = 'tls';
                        $mail->Port = 587;

                        // Recipient
                        $mail->setFrom('mr.red092697@gmail.com', 'Irene');
                        $mail->addAddress($email, $username);

                        // Content
                        $mail->isHTML(true);
                        $mail->Subject = 'Email Verification';
                        $mail->Body = 'Click the following link to verify your email: <a href="http://localhost/irene/verify.php?email=' . urlencode($email) . '">Verify Email</a>';

                        // Send email
                        $mail->send();
                        echo 'Verification email has been sent. Please check your email inbox.';
                    } catch (Exception $e) {
                        echo "Verification email could not be sent. Mailer Error: {$e->getMessage()}";
                    }
                } else {
                    echo "Error: " . $sql . "<br>" . $con->error;
                }
                
                // Close statement
                $stmt->close();
            }
        }
    }
} else {
    // Redirect back to the registration page if accessed directly
    header("Location: index.php");
    exit();
}

// Close connection
$con->close();
?>
