<?php
// Include database configuration
include 'config/config.php';

// Google reCAPTCHA secret key
$recaptcha_secret = '6LdnO9EpAAAAAFpLH33pRbYJ7OuquL-0ZdLLaEoD';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verify reCAPTCHA response
    $recaptcha_response = $_POST['g-recaptcha-response'];
    $remote_ip = $_SERVER['REMOTE_ADDR'];
    $recaptcha_url = 'https://www.google.com/recaptcha/api/siteverify';
    $recaptcha_data = array(
        'secret' => $recaptcha_secret,
        'response' => $recaptcha_response,
        'remoteip' => $remote_ip
    );

    $recaptcha_options = array(
        'http' => array(
            'method' => 'POST',
            'header' => 'Content-Type: application/x-www-form-urlencoded', // Explicitly set Content-Type
            'content' => http_build_query($recaptcha_data)
        )
    );
    
    $recaptcha_context = stream_context_create($recaptcha_options);
    $recaptcha_result = file_get_contents($recaptcha_url, false, $recaptcha_context);
    $recaptcha_json = json_decode($recaptcha_result);

    if ($recaptcha_json->success) {
        // reCAPTCHA verification successful

        // Retrieve form data
        $email = trim($_POST["email"]); // Trim the email input
        $password = $_POST["password"];

        // Prepare SQL statement to retrieve user data from the database
        $sql = "SELECT * FROM users WHERE LOWER(Email) = LOWER(?) AND VerificationStatus = 'Verified'";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        // Debugging: Output SQL query
        echo "SQL Query: $sql<br>";

        // Debugging: Output number of rows returned by the query
        echo "Number of rows returned: " . $result->num_rows . "<br>";

        if ($result->num_rows == 1) {
            // Fetch user data
            $user = $result->fetch_assoc();
        
            // Verify password
            if ($password === $user['Password']) { // Compare plain-text passwords
                // Password is correct, redirect to home.php
                header("Location: ss.html");
                exit();
            } else {
                // Password is incorrect, display error message
                echo "Incorrect password.";
            }
        } else {
            // User does not exist or is not verified, display error message
            echo "User not found or not verified.";
        }
        

        // Close statement
        $stmt->close();
    } else {
        // reCAPTCHA verification failed, display error message
        echo "reCAPTCHA verification failed. Please try again.";
    }
} else {
    // Redirect back to the sign-in page if accessed directly
    header("Location: index.php");
    exit();
}

// Close connection
$con->close();
?>
