<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';
function isUserAuthenticated() {
    if (isset($_SESSION['SESSION_EMAIL'])) {
        return true; // User is authenticated
    } else {
        return false; // User is not authenticated
    }
}

function registerUser($conn, $name, $email, $password, $code) {
    if (mysqli_num_rows(mysqli_query($conn, "SELECT * FROM users WHERE email='{$email}'")) > 0) {
        return "This email address already exists.";
    }

    $sql = "INSERT INTO users (name, email, password, code) VALUES ('{$name}', '{$email}', '{$password}', '{$code}')";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        // Send verification email
        $sent = sendVerificationEmail($email, $code);

        return $sent ? "Registration successful. Verification link sent to your email." : "Registration successful, but the verification email couldn't be sent.";
    } else {
        return "Something went wrong during registration.";
    }
}

function sendVerificationEmail($email, $code) {
    $mail = new PHPMailer(true);

    try {
        $mail->SMTPDebug = 0;
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'mr.red092697@gmail.com';
        $mail->Password = 'zhjnupdqobuipamz';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port = 465;
        $mail->setFrom('mr.red092697@gmail.com');
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = 'no reply';
        $mail->Body = 'Here is the verification link <b><a href="http://localhost/grantye/?verification=' . $code . '">Click Me!</a></b>';

        $mail->send();
        return true; // Email sent successfully
    } catch (Exception $e) {
        return false; // Email sending failed
    }
}
//in index for verication
function getUserInfo($conn, $email) {
    $email = mysqli_real_escape_string($conn, $email);
    $query = "SELECT * FROM users WHERE email='$email'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        return mysqli_fetch_assoc($result);
    } else {
        return false;
    }
}


?>
