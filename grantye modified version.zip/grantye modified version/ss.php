<?php
session_start();
if (!isset($_SESSION['SESSION_EMAIL'])) {
    header("Location: index.php");
    die();
}
require 'functions.php';
require 'config.php';

// Retrieve user information
$userEmail = $_SESSION['SESSION_EMAIL'];
$userInfo = getUserInfo($conn, $userEmail);

if (!$userInfo) {
    // User not found
    header("Location: index.php");
    die();
}

// Get the user's name and email
$userName = $userInfo['name'];
$userEmail = $userInfo['email'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Welcome</title>
  <link rel="stylesheet" href="css/ss.css" type="text/css"> 
<body>
  <div class= "container">
      <div class="bubbles">
      <span style="--i:11"></span>
      <span style="--i:12"></span>
      <span style="--i:24"></span>
      <span style="--i:10"></span>
      <span style="--i:14"></span>
      <span style="--i:23"></span>
      <span style="--i:18"></span>
      <span style="--i:16"></span>
      <span style="--i:19"></span>
      <span style="--i:20"></span>
      <span style="--i:22"></span>
      <span style="--i:25"></span>
      <span style="--i:18"></span>
      <span style="--i:21"></span>
      <span style="--i:15"></span>
      <span style="--i:13"></span>
      <span style="--i:26"></span>
      <span style="--i:17"></span>
      <span style="--i:13"></span>
      <span style="--i:28"></span>
      <span style="--i:11"></span>
      <span style="--i:12"></span>
      <span style="--i:24"></span>
      <span style="--i:10"></span>
      <span style="--i:14"></span>
      <span style="--i:23"></span>
      <span style="--i:18"></span>
      <span style="--i:16"></span>
      <span style="--i:19"></span>
      <span style="--i:20"></span>
      <span style="--i:22"></span>
      <span style="--i:25"></span>
      <span style="--i:18"></span>
      <span style="--i:21"></span>
      <span style="--i:15"></span>
      <span style="--i:13"></span>
      <span style="--i:26"></span>
      <span style="--i:17"></span>
      <span style="--i:13"></span>
      <span style="--i:28"></span>
      </div>
  </div>
  <div class="overlay-container">
  <div id="user-info">
    <h1>Hello, <?php echo $userName; ?> to your landing page</h1>
    <p>Email: <?php echo $userEmail; ?></p>
  </div>
  <div id="image-container">
    <img id="random-image" src="images/wer.jpg" alt="Random Image">
    <button id="randomize-button" onclick="randomizeImage()">Randomize Image</button>
    <a id="logout-button" href='logout.php'>Logout</a>
  </div>
</div>


<script>
  // List of image URLs
  const imageUrls = [
    'images/wer.jpg',
    'images/wer1.jpg',
    'images/wer2.jpg',
    'images/wer3.jpg',
  ];

  function randomizeImage() {
    const randomIndex = Math.floor(Math.random() * imageUrls.length);
    const randomImageUrl = imageUrls[randomIndex];
    document.getElementById('random-image').src = randomImageUrl;
  }
</script>

</body>
</html>
