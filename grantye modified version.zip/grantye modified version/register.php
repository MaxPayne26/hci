<?php
session_start();

// Include functions and config
require 'functions.php';
require 'config.php';

// Check if the user is already authenticated
if (isUserAuthenticated()) {
    header("Location: ss.php");
    die();
}

$msg = "";

if (isset($_POST['submit'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, md5($_POST['password']));
    $code = mysqli_real_escape_string($conn, md5(rand())); // Generate a code for verification

    // Register the user
    $msg = registerUser($conn, $name, $email, $password, $code);
}


?>


<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Register Form</title>
    <!-- Meta tag Keywords -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8" />
    <meta name="keywords" content="Login Form" />
    <!-- //Meta tag Keywords -->

    <link href="//fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/register.css" type="text/css"> <!-- Link to the external CSS file -->

    <style>
        body {
            background-image: url(images/bg.jpg);
            background-size: cover;
        }
    </style>
</head>

<body>
    <section class="siktyun">
        <div class="container">
            <div class="content-wthree">
                <h2>Registration Form</h2>

                <?php if ($msg) : ?>
                    <div class="php-message">
                        <?php echo $msg; ?>
                    </div>
                <?php endif; ?>
                <form action="" method="post">
                    <h1>Create Your Account</h1>
                    <input type="text" name="name" placeholder="Enter Your Name" required>
                    <input type="email" name="email" placeholder="Enter Your Email" required>
                    <input type="password" name="password" placeholder="Enter Your Password" required>
                    <input type="password" name="confirm-password" placeholder="Enter Your Password Again" required>
                    <div class="button-container">
                        <button name="submit" type="submit">Register</button>
                    </div>
                </form>
                <div class="social-icons">
                    <p>Already Have an Account? <a href="index.php">Login</a>.</p>
                </div>
            </div>
        </div>
    </section>
    <!-- //form section start -->
</body>

</html>
