<?php

$conn = mysqli_connect("localhost", "root", "", "databaseforusers");

if (!$conn) {
    echo "Connection Failed";
}
